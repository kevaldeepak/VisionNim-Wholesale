import './App.css'

// Components
import Navbar from './components/Navbar'

function App() {

    return (
        <>
            <Navbar></Navbar>
            <section id="splash-page">
                <h1 className='MainName' >VISIONIM WHOLESALE</h1>
                <h3>Scroll Down</h3>
            </section>
            <section id="WhoWeAre">

            </section>
            <section id='WhatWeOffer'>

            </section>
            <section id='Contact'>

            </section>


        </>
    )
}

export default App
